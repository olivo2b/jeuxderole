/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jeux.de.role;

/**
 *
 * @author Aflokkat
 */
public class JeuxDeRole {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Monstres ratman = new Monstres (20, 20, 20, true);
        Personnage Diogo = new Personnage ();
      while ((Diogo.getPv() >0) && (ratman.getVie())){
          if (ratman.getVie()){
      
         Diogo.jouer(ratman);
        ratman.jouer(Diogo);
          }
        Diogo.win(ratman);
        ratman.loose(Diogo) ;    
         }
        
     
    }
   
      }
    

    

